DROP TABLE IF EXISTS PNC_USER;
create table PNC_USER(USER_ID INT NOT NULL, FIRST_NAME VARCHAR(20),LAST_NAME VARCHAR(20),ACCOUNT_TYPE VARCHAR(20),ADDRESS VARCHAR(30),MOBILE_NUM VARCHAR(20),MAIL_ID VARCHAR(30), PRIMARY KEY (USER_ID) );
INSERT INTO PNC_USER values(1,'Jhon', 'Deblin', 'Checking', '8100 Anderson mill road', '(789)502-3377', 'Jhon.Deblin@gamil.com');
INSERT INTO PNC_USER values(2, 'Don', 'Mesterlin', 'Savings', '7700 West parmer lane', '(334)543-9988', 'Don.Mesterlin@gmail.com');
INSERT INTO PNC_USER values(3, 'Steve', 'Michel', 'Personal Loan', '1818 Cyprus creek park', '(889)998-9988', 'Steve.Michel@gnail.com');
