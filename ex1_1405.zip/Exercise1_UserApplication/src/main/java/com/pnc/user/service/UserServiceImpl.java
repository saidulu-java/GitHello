package com.pnc.user.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.pnc.user.exception.ResourceNotFoundException;
import com.pnc.user.model.User;
import com.pnc.user.repository.UserRepository;

/**
 * @author Shravan
 *
 */
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepository;

	private static Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	@Override
	public List<User> getUsers() {
		logger.info("UserServiceImpl :: getUsers :: Get list of users");
		return(List<User>) userRepository.findAll();
	}
	@Override
	public User updateUserDetails(User newUser, int userId) {
		logger.info("UserServiceImpl :: updateUserDetails :: Updating user detail");
	
		return userRepository.findById(userId).map(user -> {
			user.setFirstName(newUser.getFirstName());
			user.setDateofBirth(newUser.getDateofBirth());
			return userRepository.save(user);
		}).orElseThrow(() -> new ResourceNotFoundException("User [Id="+userId+"] can't be found"));
		
	}

	@Override
	public void deleteUser(int userId) {
		logger.info("UserServiceImpl :: deleteUser :: Deleteing user");
		userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User [Id="+userId+"] can't be found"));
		userRepository.deleteById(userId);
	}

	
	@Override
	public User findUserById(int userId) {
		logger.info("UserServiceImpl :: findUserById :: Finding user by userId");
		//Optional<User> user = userRepository.findById(userId);	
		return userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User [Id="+userId+"] can't be found"));
	
	}


	@Override
	public void saveUser(User user) {
		userRepository.save(user);
	}
	@Override
	public long getUserCount() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
