package com.pnc.user.model;

import java.util.List;

public class ServiceResponse {
	

	private boolean status;
	private Object body;
	private List<Errors> errors;
	
	/**
	 * @return the status
	 */
	public boolean isStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(boolean status) {
		this.status = status;
	}

	/**
	 * @return the body
	 */
	public Object getBody() {
		return body;
	}

	/**
	 * @param body the body to set
	 */
	public void setBody(Object body) {
		this.body = body;
	}

	/**
	 * @return the errors
	 */
	public List<Errors> getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<Errors> errors) {
		this.errors = errors;
	}

	
	public ServiceResponse(boolean status,Object body, List errors) {
		this.status = status;
		this.body = body;
		this.errors  =  errors;
		
		
	}
/*
	public static ResponseStatus forSuccess(int code, boolean status, String message) {
		return new ResponseStatus(code, status, message);
	}
	*/

	public ServiceResponse() {
		// TODO Auto-generated constructor stub
	}

}
