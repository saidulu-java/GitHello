package com.pnc.user.rest.service.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pnc.user.exception.UserServiceException;
import com.pnc.user.model.ServiceResponse;
import com.pnc.user.model.User;
import com.pnc.user.service.UserService;
import com.pnc.user.util.Constants;

/**
 * @author Shravan
 *
 */
@RestController
@RequestMapping()
public class UserController {
	ServiceResponse serviceStatusDto = new ServiceResponse();

	@Autowired
	UserService userService;

	/**
	 * POST /create --> Create a new user and save it in the database.
	 * 
	 * @param dto
	 * @return
	 */
	@PostMapping("/users")
	@ResponseStatus(code = HttpStatus.CREATED)
	public void createUser(@Valid @RequestBody User user) {
			userService.saveUser(user);
	}
	

	/**
	 * GET /read --> Read a User by userId from the database.
	 * 
	 * @param userId
	 * @return
	 */
	@GetMapping("/{userId}")
	@ResponseStatus(code = HttpStatus.FOUND)
	public ResponseEntity<User> getSingleUser(@PathVariable int userId){
		User user = userService.findUserById(userId);
		return ResponseEntity.ok(user);

	}

	/**
	 * GET /update --> Update a User record and save it in the database.
	 * 
	 * @param userBO
	 * @return
	 * @throws UserServiceException
	 */
	@PutMapping("/updateUser/{userId}")
	public ResponseEntity<User> update(@Valid @RequestBody User user, @PathVariable Integer userId) throws UserServiceException {
		User udpatedUser = userService.updateUserDetails(user, userId);
		return ResponseEntity.ok(udpatedUser);

	}


	/**
	 * GET /delete --> Delete a user from the database.
	 * 
	 * @param userId
	 * @return
	 * @throws UserServiceException
	 */
	@DeleteMapping("/deleteUser/{userId}")
	public ResponseEntity<ServiceResponse> delete(@Valid @PathVariable Integer userId) throws UserServiceException {
		userService.deleteUser(userId);
		return new ResponseEntity<ServiceResponse>(serviceStatusDto, HttpStatus.OK);
	}

}
