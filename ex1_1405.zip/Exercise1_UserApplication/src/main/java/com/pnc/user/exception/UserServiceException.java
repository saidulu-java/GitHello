package com.pnc.user.exception;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.List;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnore;

public final class UserServiceException extends RuntimeException  {

	private static final long serialVersionUID = 1L;

	/**
	 * contains redundantly the HTTP status of the response sent back to the client
	 * in case of error,
	*/
	String message;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;

	}
	public UserServiceException() {
		super();
	}
	public UserServiceException(String message) {
		super(message);
	}
	
}
