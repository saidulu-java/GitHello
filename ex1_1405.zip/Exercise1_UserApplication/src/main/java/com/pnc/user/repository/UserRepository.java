package com.pnc.user.repository;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.pnc.user.model.User;

@Transactional
public interface UserRepository extends CrudRepository<User, Integer> {
	
}
