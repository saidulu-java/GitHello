package com.example3.user.aggregate.application.utils;

import java.util.ArrayList;
import java.util.List;
public class AggregateServiceUtil {

//	/**
//	 * Converts List of UserDAO objects to UserDTO objects
//	 * 
//	 * @param users
//	 * @return List of UserDTO objects
//	 */
//	public static List<AccountDTO> convertDaoListToDto(List<Account> accounts) {
//		List<AccountDTO> accountDTO = new ArrayList<AccountDTO>();
//
//		if (accounts != null) {
//			for (Account account : accounts) {
//				AccountDTO userDto = new AccountDTO();
//				userDto.setAccountNumber(account.getAccountNumber());
//				userDto.setAccountName(account.getAccountName());
//				userDto.setAccountBalance(account.getAccountBalance());
//
//			}
//		}
//		return accountDTO;
//	}
//
//	/**
//	 * @param accountdto
//	 * @return
//	 */
//	public static Account convertDtoObjectTODao(AccountDTO accountdto) {
//		Account account = new Account();
//		account.setAccountNumber(accountdto.getAccountNumber());
//		account.setAccountName(accountdto.getAccountName());
//		account.setAccountBalance(accountdto.getAccountBalance());
//
//		return account;
//	}

}