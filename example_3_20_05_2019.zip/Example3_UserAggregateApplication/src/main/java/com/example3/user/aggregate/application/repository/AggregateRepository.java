package com.example3.user.aggregate.application.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example3.user.aggregate.application.model.UserAccount;

/**
 * @author Shravan
 *
 */
@Repository
public interface AggregateRepository extends JpaRepository<UserAccount, Integer> {
	
}
