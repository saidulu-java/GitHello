package com.example3.user.aggregate.application.utils;

/**
 * @author Shravan
 *
 */
public class Constants {

	public static final String ERROR_MESSAGE = "Error While Creating Record !!";
	public static final String UNKNOWN_EXCEPTION = "Unknown Exception !!";
	public static final String INTERNALSERVERERROR = "Internal Server Error !!";

	public static final String USER_UPDATED = "User updated Successfully !!";
	public static final String USER_DELETED = "User Deleted Successfully !!";
	public static final String USER_NOT_EXISTS = "User doesnot Exists !!";
	public static final String USER_CREATED = "Users Created Successfully !!";
	public static final String USER_EXISTS = "Users Already Exists  !!";
	public static final String USERS_NOT_PRESENT = "Current No User Found Please Create User !!";
	
	public static final String SUCCESS = "Success";
	public static final String ERROR = "Error";
	
	
	

}
