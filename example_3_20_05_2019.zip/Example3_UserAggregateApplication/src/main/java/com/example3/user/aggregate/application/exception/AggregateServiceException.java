package com.example3.user.aggregate.application.exception;

public final class AggregateServiceException extends RuntimeException  {

	private static final long serialVersionUID = 1L;

	/**
	 * contains redundantly the HTTP status of the response sent back to the client
	 * in case of error,
	*/
	String message;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;

	}
	public AggregateServiceException() {
		super();
	}
	public AggregateServiceException(String message) {
		super(message);
	}
	
}
