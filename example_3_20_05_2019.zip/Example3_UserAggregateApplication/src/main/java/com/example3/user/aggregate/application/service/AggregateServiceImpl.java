package com.example3.user.aggregate.application.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example3.user.aggregate.application.model.UserAccount;
import com.example3.user.aggregate.application.repository.AggregateRepository;

/**
 * @author Shravan
 *
 */
@Service
public class AggregateServiceImpl implements AggregateService {

	@Autowired
	AggregateRepository accountRepository;

	private static Logger logger = LoggerFactory.getLogger(AggregateServiceImpl.class);
	
	@Override
	public UserAccount saveUserTagAccount(UserAccount userAcc) {
		logger.info("Creating UserTagAccount *****");
		
		return accountRepository.save(userAcc);
	}

}
