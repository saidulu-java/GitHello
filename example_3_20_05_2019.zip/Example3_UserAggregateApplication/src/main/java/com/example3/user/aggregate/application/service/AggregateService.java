package com.example3.user.aggregate.application.service;

import com.example3.user.aggregate.application.model.UserAccount;

/**
 * 
 * @author Shravan
 *
 */

public interface AggregateService {

	/**
	 * 
	 * @param usertagaccount
	 * @return useraccount
	 */

	public UserAccount saveUserTagAccount(UserAccount userAcc);

}
