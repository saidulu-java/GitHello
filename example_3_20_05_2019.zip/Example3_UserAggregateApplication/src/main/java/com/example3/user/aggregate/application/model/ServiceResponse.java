package com.example3.user.aggregate.application.model;

import java.io.Serializable;
import java.util.List;

/**
 * @author Shravan
 *
 */
public class ServiceResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String status;
	private Object body;
	private List<ErrorResponse> errors;

	public Object getBody() {
		return body;
	}


	public String getStatus() {
		return status;
	}


	public void setBody(Object body) {
		this.body = body;
	}


	public void setStatus(String status) {
		this.status = status;
	}

	public List<ErrorResponse> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorResponse> errors) {
		this.errors = errors;
	}

	public ServiceResponse() {
		// TODO Auto-generated constructor stub
	}

}
