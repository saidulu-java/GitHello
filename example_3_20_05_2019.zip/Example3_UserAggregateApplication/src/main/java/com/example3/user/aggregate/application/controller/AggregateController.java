package com.example3.user.aggregate.application.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example3.user.aggregate.application.model.Account;
import com.example3.user.aggregate.application.model.AccountDTO;
import com.example3.user.aggregate.application.model.ServiceResponse;
import com.example3.user.aggregate.application.model.UserAccount;
import com.example3.user.aggregate.application.model.UserDTO;
import com.example3.user.aggregate.application.service.AggregateService;
import com.example3.user.aggregate.application.utils.Constants;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Shravan
 *
 */
@RestController
@RequestMapping()
public class AggregateController {
	ServiceResponse response = new ServiceResponse();

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	AggregateService aggregateService;

	/**
	 * POST /create --> Create a new Account and save it in the database.
	 * 
	 * @param dto
	 * @Parm custid or userid
	 * @return
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	@PostMapping("aggregate/user/account")
	public ResponseEntity<ServiceResponse> createAccount(@Valid @RequestBody UserAccount useracc) throws JsonParseException, JsonMappingException, IOException {
		

		// Getting User Data 
		///user/{userId}
		String userResponse = restTemplate.getForObject("http://localhost:8181/user/"+useracc.getUserid(), String.class);
		System.out.println(userResponse);
		ObjectMapper mapper = new ObjectMapper();
		UserDTO userDto = (UserDTO) mapper.readValue(userResponse, new TypeReference<UserDTO>() {});
		//LinkedHashMap userDto = (LinkedHashMap)sres.getBody();

		useracc.setFirstName(userDto.getFirstName());
		useracc.setLastName(userDto.getLastName());
		useracc.setMobile(userDto.getMobile());
		useracc.setEmail(userDto.getEmail());
		
		// Getting Account Data
		// /accounts/get/{accountNumber}
		String accountResponse = restTemplate.getForObject("http://localhost:8282/accounts/get/"+useracc.getAccountNumber(), String.class);
		System.out.println(accountResponse);
		Account accountDto = (Account) mapper.readValue(accountResponse, new TypeReference<Account>() {});
		
		useracc.setAccountType(accountDto.getAccountName());
		useracc.setAccountBalance(accountDto.getAccountBalance());
		
		response.setBody(aggregateService.saveUserTagAccount(useracc));
		response.setStatus("SUCCESS");
		return new ResponseEntity<ServiceResponse>(response, HttpStatus.CREATED);

	}

	/**
	 * @return list of all the accounts
	 * @throws IOException
	 * @throws JsonProcessingException
	 */
	@GetMapping("aggregate/{userid}")
	public ResponseEntity<ServiceResponse> getAllDetails(@PathVariable Integer userid)
			throws JsonProcessingException, IOException {

		// Getting User Data

		System.out.println("======================= User id::: " + userid);
		String sresponse = restTemplate.getForObject("http://localhost:8282/accounts/getAllAccounts", String.class);

		System.out.println(sresponse);

		ObjectMapper mapper = new ObjectMapper();
		List<Account> ts = (List<Account>) mapper.readValue(sresponse, new TypeReference<List<Account>>() {
		});

		List<Account> aggList = new ArrayList<Account>();
		for (Account acc : ts) {
			if (acc.getId() == userid) {
				aggList.add(acc);
			}
		}
		response.setStatus(Constants.SUCCESS);
		response.setBody(aggList);
		 
		return new ResponseEntity<ServiceResponse>(response, HttpStatus.CREATED);

	}
}
