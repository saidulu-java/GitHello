package com.example3.user.aggregate.application.model;

import java.io.Serializable;


public class Account implements Serializable {


	/**
	 * @author Shravan
	 */
	private static final long serialVersionUID = 1L;

	private Integer accountNumber;
	

	private Integer id;

	private String accountName;


	private double accountBalance;

	
	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
