package com.example2.user.account.utils;

import java.util.ArrayList;
import java.util.List;

import com.example2.user.account.model.dto.AccountDTO;
import com.example2.user.account.model.entity.Account;

public class AccountServiceUtil {

	/**
	 * Converts List of UserDAO objects to UserDTO objects
	 * 
	 * @param users
	 * @return List of UserDTO objects
	 */
	public static List<AccountDTO> convertDaoListToDto(List<Account> accounts) {
		List<AccountDTO> accountDTO = new ArrayList<AccountDTO>();

		if (accounts != null) {
			for (Account account : accounts) {
				AccountDTO userDto = new AccountDTO();
				userDto.setAccountNumber(account.getAccountNumber());
				userDto.setAccountName(account.getAccountName());
				userDto.setAccountBalance(account.getAccountBalance());

			}
		}
		return accountDTO;
	}

	/**
	 * @param accountdto
	 * @return
	 */
	public static Account convertDtoObjectTODao(AccountDTO accountdto) {
		Account account = new Account();
		account.setAccountNumber(accountdto.getAccountNumber());
		account.setAccountName(accountdto.getAccountName());
		account.setAccountBalance(accountdto.getAccountBalance());
		account.setId(accountdto.getId());

		return account;
	}

}