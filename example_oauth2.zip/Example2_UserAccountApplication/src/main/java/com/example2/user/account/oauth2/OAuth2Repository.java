package com.example2.user.account.oauth2;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * User repository for CRUD operations.
 */
public interface OAuth2Repository extends JpaRepository<User,Long> {
    Optional<User> findByUsername(String username);

	User save(User user);
}
