package com.example2.user.account.controller;

import java.io.IOException;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.example2.user.account.model.ServiceResponse;
import com.example2.user.account.model.dto.AccountDTO;
import com.example2.user.account.model.dto.UserDTO;
import com.example2.user.account.model.entity.Account;
import com.example2.user.account.service.AccountService;
import com.example2.user.account.utils.Constants;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

/**
 * @author Shravan
 *
 */
@RestController
@RequestMapping("/accounts")
public class AccountController {
	ServiceResponse response = new ServiceResponse();

	@Autowired
	AccountService accountService;
	
	@Value("${serviceURL}")
	String serviceURL;

	@Autowired
	RestTemplate restTemplate;

	/**
	 * POST /create --> Create a new Account and save it in the database.
	 * 
	 * @param account dto
	 * @Parm  userid
	 * @return new account
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	@PostMapping("/create/{userId}")
	public ResponseEntity<Account> createAccount(@Valid @RequestBody AccountDTO dto,
			@PathVariable Integer userId) throws JsonParseException, JsonMappingException, IOException {
		
		RestTemplate restTemplate = new RestTemplate();
		//ResponseEntity<ServiceResponse> response = restTemplate.exchange("http://localhost:8181/user/"+userId, HttpMethod.GET, null, new ParameterizedTypeReference<ServiceResponse>(){});
		String  restResponse = restTemplate.getForObject("http://localhost:8181/user/"+userId,String.class);
		
		ObjectMapper mapper = new ObjectMapper();
		UserDTO userDto = (UserDTO) mapper.readValue(restResponse, new TypeReference<UserDTO>() {});

		dto.setId(userDto.getId());
		Boolean status = accountService.findAccountByNumber(dto.getAccountNumber());

		if (status == true) {
			response.setStatus(Constants.ERROR);
			response.setBody(Constants.ACCOUNT_EXISTS);
			return new ResponseEntity<Account>( HttpStatus.NOT_FOUND);
		}
		else {
			Account newacc = accountService.saveAccount(dto);
			response.setStatus(Constants.SUCCESS);
			response.setBody(newacc);
			return new ResponseEntity<Account>(newacc, HttpStatus.CREATED);
		} 
	}
	
	/**
	 * POST /create --> Create a new Account and save it in the database.
	 * 
	 * @param account dto
	 * @Parm  userid
	 * @return new account
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	@PostMapping("/{userId}")
	public ResponseEntity<Account> createAccounts(@Valid @RequestBody AccountDTO dto, @PathVariable Integer userId)  {

		dto.setId(userId);
		Boolean status = accountService.findAccountByNumber(dto.getAccountNumber());
		
		if (status == true) {
			response.setStatus(Constants.ERROR);
			response.setBody(Constants.ACCOUNT_EXISTS);
			return new ResponseEntity<Account>( HttpStatus.NOT_FOUND);
		}
		else {
			Account newacc = accountService.saveAccount(dto);
			response.setStatus(Constants.SUCCESS);
			response.setBody(newacc);
			return new ResponseEntity<Account>(newacc, HttpStatus.CREATED);
		} 
	}
	

	/**
	 * @return account details
	 */
	@GetMapping("/get/{accountNumber}")
	public ResponseEntity<Account> getUserAccounts(@PathVariable Integer accountNumber) {

		Account account = accountService.findAccountById(accountNumber);
		if (account != null) {
			response.setStatus(Constants.SUCCESS);
			response.setBody(account);
			return new ResponseEntity<Account>(account, HttpStatus.OK);
		} else {
			response.setStatus(Constants.ERROR);
			response.setBody(Constants.ACCOUNT_NOT_EXISTS);
			return new ResponseEntity<Account>(HttpStatus.NOT_FOUND);
		}
	}
	/**
	 * @return account details
	 */
	@GetMapping("/{userId}")
	public ResponseEntity<List<Account>> getUserAccountsbyUserid(@PathVariable Integer userId) {
		
		List<Account> account = accountService.findById(userId);
		if (account.size() != 0) {
			response.setStatus(Constants.SUCCESS);
			response.setBody(account);
			return new ResponseEntity<List<Account>>(account, HttpStatus.CREATED);
		} else {
			response.setStatus(Constants.ERROR);
			response.setBody(Constants.ACCOUNT_NOT_EXISTS);
			return new ResponseEntity<List<Account>>(HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * @return
	 */
	@GetMapping("/getAllAccounts")
	public ResponseEntity<List<Account>> getAllAccounts() {

		List<Account> accList = accountService.getAccount();
		if (accList.size() != 0) {
			response.setStatus(Constants.SUCCESS);
			response.setBody(accList);
			return new ResponseEntity<List<Account>>(accList, HttpStatus.OK);
		} else {
			response.setStatus(Constants.ERROR);
			response.setBody(Constants.USER_NOT_EXISTS);
			return new ResponseEntity<List<Account>>(accList, HttpStatus.NOT_FOUND);
		}
	}
	
	

}
