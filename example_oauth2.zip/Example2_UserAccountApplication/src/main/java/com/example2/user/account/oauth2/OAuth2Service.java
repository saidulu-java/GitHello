package com.example2.user.account.oauth2;

import java.util.Arrays;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class OAuth2Service {

    @Autowired
    private OAuth2Repository repo;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public User save(User user){
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setActive(true);
        return repo.save(user);
    }
    
    /**
	 * 
	 * set up a default user with two roles USER and ADMIN
	 * 
	 */
	@PostConstruct
	private void setupDefaultUser() {
		//-- just to make sure there is an ADMIN user exist in the database for testing purpose
		if (repo.count() == 0) {
			repo.save(new User("admin", 
									passwordEncoder.encode("admin"), 
									Arrays.asList(new Role("USER"), new Role("ADMIN")),true));
		}		
	}

}
