package com.example2.user.account.exception;

public final class AccountServiceException extends RuntimeException  {

	private static final long serialVersionUID = 1L;

	/**
	 * contains redundantly the HTTP status of the response sent back to the client
	 * in case of error,
	*/
	String message;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;

	}
	public AccountServiceException() {
		super();
	}
	public AccountServiceException(String message) {
		super(message);
	}
	
}
