package com.example2.user.account;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example2.user.account.model.ServiceResponse;
import com.example2.user.account.model.dto.AccountDTO;
import com.example2.user.account.model.entity.Account;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Example2UserAccountApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class Example2UserAccountApplicationTests {

	@LocalServerPort
	private int port;
	AccountDTO adto = new AccountDTO();
	TestRestTemplate restTemplate = new TestRestTemplate();

	HttpHeaders headers = new HttpHeaders();

//	@Test()
	public void testRetrieveUserAccountDetails() throws JSONException, JsonParseException, JsonMappingException, IOException {

		String sresponse = restTemplate.getForObject("http://localhost:8282/accounts/getAllAccounts", String.class);
		String expected = "[{\"accountNumber\":11111,\"id\":1,\"accountName\":\"SAVING\",\"accountBalance\":1000.0},{\"accountNumber\":22222,\"id\":2,\"accountName\":\"CHECKING\",\"accountBalance\":2000.0},{\"accountNumber\":33333,\"id\":3,\"accountName\":\"LOAN\",\"accountBalance\":3000.0}]";

		System.out.println(expected);
		System.out.println(sresponse);
		
		JSONAssert.assertEquals(expected,sresponse, true);
	}
	@Test
	public void testCreateUserAccountDetails() throws JSONException, JsonParseException, JsonMappingException, IOException {
		
		HttpEntity<AccountDTO> request = new HttpEntity<>(adto);
		String userResponse = restTemplate.postForObject("http://localhost:8282/accounts/create/1", request, String.class);
		System.out.println(userResponse);
		String expected = "[{\"accountNumber\":11111,\"id\":1,\"accountName\":\"SAVING\",\"accountBalance\":1000.0},{\"accountNumber\":22222,\"id\":2,\"accountName\":\"CHECKING\",\"accountBalance\":2000.0},{\"accountNumber\":33333,\"id\":3,\"accountName\":\"LOAN\",\"accountBalance\":3000.0}]";
		
		System.out.println(expected);
		System.out.println(userResponse);
		
		JSONAssert.assertEquals(expected,userResponse, true);
	}

	private String createURLWithPort(String uri) {
		return "http://localhost:" + 8181 + uri;
	}


}
