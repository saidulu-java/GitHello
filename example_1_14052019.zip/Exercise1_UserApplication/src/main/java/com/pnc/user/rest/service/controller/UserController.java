package com.pnc.user.rest.service.controller;

import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pnc.user.model.ServiceResponse;
import com.pnc.user.model.User;
import com.pnc.user.service.UserService;
import com.pnc.user.util.Constants;

/**
 * @author Shravan
 *
 */
@RestController
@RequestMapping()
public class UserController {
	ServiceResponse serviceStatusDto = new ServiceResponse();

	@Autowired
	UserService userService;

	/**
	 * POST /create --> Create a new user and save it in the database.
	 * 
	 * @param dto
	 * @return
	 */
	@PostMapping("/users")
	@ResponseStatus(code = HttpStatus.CREATED)
	public ResponseEntity<Object> createUser(@Valid @RequestBody User user) {
		User newUser = userService.saveUser(user);
		ServiceResponse response = new ServiceResponse();
		response.setStatus("SUCCESS");
		response.setBody(newUser);
		return new ResponseEntity<Object>(response, HttpStatus.OK);
	}
	

	/**
	 * GET /read --> Read a User by userId from the database.
	 * 
	 * @param userId
	 * @return
	 */
	@GetMapping("/{userId}")
	@ResponseStatus(code = HttpStatus.FOUND)
	public ResponseEntity<Object> getSingleUser(@PathVariable int userId){
		ServiceResponse response = new ServiceResponse();
		User user = userService.findUserById(userId);
		response.setStatus("SUCCESS");
		response.setBody(user);
		return new ResponseEntity<Object>(response, HttpStatus.OK);

	}
	

	/**
	 * GET /read --> Read all users from the database.
	 * 
	 * @param findall
	 * @return
	 */
	@GetMapping("/findall")
	@ResponseStatus(code = HttpStatus.FOUND)
	public ResponseEntity<Object> getAllUsers(){
		ServiceResponse response = new ServiceResponse();
		List<User> findall = userService.getUsers();
		response.setStatus("SUCCESS");
		response.setBody(findall);
		return new ResponseEntity<Object>(response, HttpStatus.OK);

	}


	/**
	 * GET /update --> Update a User record and save it in the database.
	 * 
	 * @param userBO
	 * @return
	 * @throws UserServiceException
	 */
	@PutMapping("/updateUser/{userId}")
	public ResponseEntity<Object> update(@Valid @RequestBody User user, @PathVariable Integer userId) {
		User udpatedUser = userService.updateUserDetails(user, userId);
		ServiceResponse response = new ServiceResponse();
		response.setStatus("SUCCESS");
		response.setBody(udpatedUser);
		return new ResponseEntity<Object>(response, HttpStatus.OK);

	}


	/**
	 * GET /delete --> Delete a user from the database.
	 * 
	 * @param userId
	 * @return
	 * @throws UserServiceException
	 */
	@DeleteMapping("/deleteUser/{userId}")
	public ResponseEntity<Object> delete(@Valid @PathVariable Integer userId){
		userService.deleteUser(userId);
		ServiceResponse response = new ServiceResponse();
		response.setStatus("SUCCESS");
		response.setBody(Constants.USER_DELETED);
		return new ResponseEntity<Object>(response, HttpStatus.OK);
	}

}
