package com.pnc.user.model;

import java.util.List;

public class ServiceResponse {

	public Object getBody() {
		return body;
	}

	public void setBody(Object body) {
		this.body = body;
	}

	private String status;
	private Object body;
	private List<ErrorResponse> errors;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<ErrorResponse> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorResponse> errors) {
		this.errors = errors;
	}

	public ServiceResponse() {
		// TODO Auto-generated constructor stub
	}

}
