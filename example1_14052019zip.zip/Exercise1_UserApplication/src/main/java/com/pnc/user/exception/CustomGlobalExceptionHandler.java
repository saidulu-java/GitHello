package com.pnc.user.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.pnc.user.model.ErrorResponse;
import com.pnc.user.model.ServiceResponse;

@SuppressWarnings({ "unchecked", "rawtypes" })
@ControllerAdvice
public class CustomGlobalExceptionHandler extends ResponseEntityExceptionHandler {
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {

		ErrorResponse errorRes = new ErrorResponse();
		errorRes.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		errorRes.setMessage(ex.getLocalizedMessage());

		List<ErrorResponse> errors = new ArrayList<>();
		errors.add(errorRes);

		ServiceResponse serviceErr = new ServiceResponse();
		serviceErr.setErrors(errors);
		serviceErr.setStatus("ERROR");

		return new ResponseEntity(serviceErr, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(ResourceNotFoundException.class)
	public final ResponseEntity<Object> handleUserNotFoundException(ResourceNotFoundException ex, WebRequest request) {

		ErrorResponse errorRes = new ErrorResponse();
		errorRes.setCode(HttpStatus.NOT_FOUND.value());
		errorRes.setMessage(ex.getLocalizedMessage());

		List<ErrorResponse> errors = new ArrayList<>();
		errors.add(errorRes);

		ServiceResponse serviceErr = new ServiceResponse();
		serviceErr.setErrors(errors);
		serviceErr.setStatus("ERROR");

		return new ResponseEntity(serviceErr, HttpStatus.NOT_FOUND);
	}

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		List<ErrorResponse> errors = new ArrayList<>();

		ErrorResponse errorRes = new ErrorResponse();
		errorRes.setCode(HttpStatus.BAD_REQUEST.value());

		for (ObjectError error : ex.getBindingResult().getAllErrors()) {
			errorRes.setMessage(error.getDefaultMessage());
		}

		ServiceResponse serviceErr = new ServiceResponse();
		serviceErr.setErrors(errors);
		serviceErr.setStatus("ERROR");

		return new ResponseEntity(serviceErr, HttpStatus.BAD_REQUEST);

	}
}