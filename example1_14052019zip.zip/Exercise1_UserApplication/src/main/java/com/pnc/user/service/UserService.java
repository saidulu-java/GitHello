package com.pnc.user.service;


import java.util.List;
import java.util.Optional;

import com.pnc.user.model.User;

/**
 * 
 * @author Shravan
 *
 */
public interface UserService {

	/**
	 * Deletes given user
	 * @param userId
	 */
	public void deleteUser(int userId);

	/**
	 * Updates given user
	 * @param user
	 * @return 
	 */

	public User updateUserDetails(User user, int userId);


	/**
	 * Find user given by userId
	 * @param userId
	 * @return user activeStatus
	 */
	public User findUserById(int userId);

	/**
	 * Returns list of users
	 * @return list of userDto objects
	 */
	List<User> getUsers(); 

	/**
	 * Returns users count
	 * @return No.of users count
	 */
	long getUserCount();

	/**
	 * 
	 * @param userDto
	 */

	public User saveUser(User user);

}
