package com.pnc.user.rest.controller;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.pnc.user.exception.UserServiceException;
import com.pnc.user.model.ServiceResponse;
import com.pnc.user.model.dto.UserDTO;
import com.pnc.user.model.entity.User;
import com.pnc.user.service.UserService;
import com.pnc.user.util.Constants;


/**
 * @author Shravan
 * @param <T>
 * @param <T>
 *
 */
@RestController
@RequestMapping()
public class UserController{

	ServiceResponse response = new ServiceResponse();

	@Autowired
	UserService userService;

	/**
	 * POST /create --> Create a new user and save it in the database.
	 * 
	 * @param dto
	 * @return
	 */
	@PostMapping("/users")
	public ResponseEntity<ServiceResponse<UserDTO>> createUser(@Valid @RequestBody UserDTO dto) {
			UserDTO newusr = userService.saveUser(dto);
			response.setStatus(Constants.SUCCESS);
			response.setBody(newusr);
			return  new ResponseEntity<ServiceResponse<UserDTO>>(response, HttpStatus.CREATED);
	}

	/**
	 * GET /read --> Read a User by userId from the database.
	 * 
	 * @param userId
	 * @return
	 */
	@GetMapping("/{userId}")
	public ResponseEntity<UserDTO> getSingleUser(@PathVariable Integer userId) {
		UserDTO newusr = userService.findUserById(userId);
		response.setStatus(Constants.SUCCESS);
		response.setBody(newusr);
		return new ResponseEntity<UserDTO>(newusr, HttpStatus.FOUND);

	}

	/**
	 * GET /update --> Update a User record and save it in the database.
	 * 
	 * @param userBO
	 * @return
	 * @throws UserServiceException
	 */
	@PutMapping("/updateUser/{userId}")
	public ResponseEntity<ServiceResponse<User>> update(@Valid @RequestBody UserDTO newUser, @PathVariable Integer userId) {

		User udto = userService.updateUserDetails(newUser, userId);
		response.setStatus(Constants.SUCCESS);
		response.setBody(udto);		
		return new ResponseEntity<ServiceResponse<User>>(response, HttpStatus.CREATED);

	}
	/**
	 * GET /delete --> Delete a user from the database.
	 * 
	 * @param userId
	 * @return
	 * @throws UserServiceException
	 */
	@DeleteMapping("/deleteUser/{userId}")
	public ResponseEntity<ServiceResponse> delete(@Valid @PathVariable Integer userId)  {
		Integer id = userService.deleteUser(userId);
		response.setStatus(Constants.SUCCESS);	
		return new ResponseEntity<ServiceResponse>(response, HttpStatus.NO_CONTENT);
	}

	/**
	 * @return
	 */
	@GetMapping("/getAllUsers")
	public ResponseEntity<ServiceResponse> getAllUsers() {

		List<User> use = userService.getUsers();
		if (use.size() != 0) {
			response.setStatus(Constants.SUCCESS);
			response.setBody(use);
			return new ResponseEntity<ServiceResponse>(response, HttpStatus.CREATED);
		} else {
			response.setStatus(Constants.ERROR);
			response.setBody(Constants.USER_NOT_EXISTS);
			return new ResponseEntity<ServiceResponse>(response, HttpStatus.NOT_FOUND);
		}
	}

}
