package com.pnc.user.repository;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.pnc.user.model.entity.User;

/**
 * @author Shravan
 *
 */
@Transactional
public interface UserRepository extends CrudRepository<User, Integer> {
	
}
