package com.pnc.user.model;

public class ResponseWrapper<T extends ServiceResponse<?>> {
	T response;

	public T getResponse() {
		return response;
	}

	public void setResponse(T response) {
		this.response = response;
	}
}