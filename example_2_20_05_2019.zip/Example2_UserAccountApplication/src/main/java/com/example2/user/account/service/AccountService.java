package com.example2.user.account.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example2.user.account.model.dto.AccountDTO;
import com.example2.user.account.model.entity.Account;

/**
 * 
 * @author Shravan
 *
 */
public interface AccountService {

	/**
	 * Find account given by userId
	 * 
	 * @param userId
	 * @return user account
	 */
	public Account findAccountById(int userId);

	/**
	 * Returns list of users
	 * 
	 * @return list of account
	 */
	List<Account> getAccount();

	/**
	 * 
	 * @param user
	 * @return
	 */

	public Account saveAccount(AccountDTO dto);

	public Boolean findAccountByNumber(Integer accountNumber);

	/**
	 * 
	 * @param userId
	 * @return account
	 */
	//public Account getUserAccount(Integer userId);


}
