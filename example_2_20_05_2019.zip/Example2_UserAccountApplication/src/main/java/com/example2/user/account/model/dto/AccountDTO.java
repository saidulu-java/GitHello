package com.example2.user.account.model.dto;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountDTO implements Serializable {



	/**
	 * Shravan
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@NotNull
	private Integer accountNumber;
	
	private Integer id;

	@NotEmpty
//	@Size(max = 10, min = 5, message = "Please enter valid account Name min = 5, max = 10")
	private String accountName;

	@NotNull(message = "Please provide account balance")
	private double accountBalance;

	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

}
