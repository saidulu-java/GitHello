package com.example2.user.account;

import java.math.BigDecimal;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.example2.user.account.model.entity.Account;
import com.example2.user.account.repository.AccountRepository;

@SpringBootApplication
public class Example2UserAccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(Example2UserAccountApplication.class, args);
	}
	
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
    @Bean
    CommandLineRunner initDatabase(AccountRepository repository) {
        return args -> {
        	Account acc = new Account();
        	acc.setAccountBalance(1000);
        	acc.setAccountName("SAVING");
        	acc.setAccountNumber(11111);
        	acc.setId(1);
            repository.save(acc);
            
          	Account acc2 = new Account();
        	acc2.setAccountBalance(2000);
        	acc2.setAccountName("CHECKING");
        	acc2.setAccountNumber(22222);
        	acc2.setId(2);
            repository.save(acc2);
            
          	Account acc3 = new Account();
        	acc3.setAccountBalance(3000);
        	acc3.setAccountName("LOAN");
        	acc3.setAccountNumber(33333);
        	acc3.setId(3);
            repository.save(acc3);
        };
    }
}
