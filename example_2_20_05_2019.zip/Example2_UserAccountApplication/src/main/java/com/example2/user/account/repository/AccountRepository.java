package com.example2.user.account.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example2.user.account.model.entity.Account;

/**
 * @author Shravan
 *
 */
@Transactional
public interface AccountRepository extends CrudRepository<Account, Integer> {
	
}
