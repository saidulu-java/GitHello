package com.example2.user.account.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example2.user.account.exception.AccountServiceException;
import com.example2.user.account.model.dto.AccountDTO;
import com.example2.user.account.model.entity.Account;
import com.example2.user.account.repository.AccountRepository;
import com.example2.user.account.utils.AccountServiceUtil;

/**
 * @author Shravan
 *
 */
@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepository accountRepository;

	private static Logger logger = LoggerFactory.getLogger(AccountServiceImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.pnc.user.service.UserService#saveUser(com.pnc.user.model.UserDTO)
	 */
	public Account saveAccount(AccountDTO accountDto) throws AccountServiceException{
		logger.info("AccountServiceImpl :: CreateAccount :");
		Integer userid = accountDto.getId();

		if (null != accountDto.getAccountNumber()) {
			Optional<Account> optAcct = accountRepository.findById(accountDto.getAccountNumber());
			if ((optAcct.isPresent() && userid == optAcct.get().getId())
					&& (optAcct.get().getAccountNumber() == accountDto.getAccountNumber())) {
				System.out.println("Account Number and User Id Same..");
				new AccountServiceException("User Account Already Exists..");
			}
		}
			Account account = AccountServiceUtil.convertDtoObjectTODao(accountDto);
			return accountRepository.save(account);
	}

	@Override
	public Account findAccountById(int userId) {
		logger.info("AccountServiceImpl :: findAccountById :: Finding account by userId");
		return accountRepository.findById(userId)
				.orElseThrow(() -> new com.example2.user.account.exception.ResourceNotFoundException(
						"Account [Id=" + userId + "] can't be found"));
	}

	@Override
	public List<Account> getAccount() {
		logger.info("AccountServiceImpl :: getUsers :: Get list of users");

		List<Account> users = (List<Account>) accountRepository.findAll();
		return users;
	}

	@Override
	public Boolean findAccountByNumber(Integer accountNumber) {
		Optional<Account> acc = accountRepository.findById(accountNumber);
		Boolean status = acc.isPresent();
		System.out.println("Status ::: account exits:::"+status);
		return status;
	}

}
