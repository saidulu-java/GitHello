package com.example2.user.account;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example2.user.account.model.ServiceResponse;
import com.example2.user.account.model.entity.Account;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Example2UserAccountApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class Example2UserAccountApplicationTests {

	@LocalServerPort
	private int port;

	TestRestTemplate restTemplate = new TestRestTemplate();

	HttpHeaders headers = new HttpHeaders();

	@Test
	public void testRetrieveUserAccountDetails() throws JSONException, JsonParseException, JsonMappingException, IOException {

		ServiceResponse response = restTemplate.getForObject(createURLWithPort("/getAllAccounts"), ServiceResponse.class);
		String jsonStr = response.getBody().toString();
		
		String expected = "{\"status\":\"SUCCESS\",\"body\":{\"accountNumber\":111,\"id\":1,\"accountName\":\"HOMELOAN\",\"accountBalance\":1000.0},\"errors\":null}";
		// String expected ="{"status":"Success","body":[{"accountNumber":222,"id":4,"accountName":"SAVING","accountBalance":1000.0}],"errors":null}"
		JSONAssert.assertEquals(expected, response.getBody().toString(), false);
	}

	private String createURLWithPort(String uri) {
		return "http://localhost:" + 8181 + uri;
	}


}
