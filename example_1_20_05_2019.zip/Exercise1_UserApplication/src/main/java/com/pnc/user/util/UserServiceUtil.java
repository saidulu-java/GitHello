package com.pnc.user.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.pnc.user.model.dto.UserDTO;
import com.pnc.user.model.entity.User;

public class UserServiceUtil {

	/**
	 * Converts List of UserDAO objects to UserDTO objects
	 * 
	 * @param users
	 * @return List of UserDTO objects
	 */
	public static List<UserDTO> convertDaoListToDto(List<User> users) {
		List<UserDTO> userDTO = new ArrayList<UserDTO>();

		if (users != null) {
			for (User user : users) {
				UserDTO userDto = new UserDTO();
				userDto.setId(user.getId());
				userDto.setFirstName(user.getFirstName());
				userDto.setLastName(user.getLastName());
				userDto.setAccountType(user.getAccountType());
				userDto.setAddress(user.getAddress());
				userDto.setEmail(user.getEmail());
				userDto.setMobile(user.getMobile());
				userDTO.add(userDto);
			}
		}
		return userDTO;
	}

	/**
	 * Converts UserDAO object to UserDTO object
	 * 
	 * @param user
	 * @return UserDTO object
	 */
	public static UserDTO convertDaoObjectToDto(User user) {
		UserDTO userDTO = new UserDTO();
		userDTO.setId(user.getId());
		userDTO.setFirstName(user.getFirstName());
		userDTO.setAccountType(user.getAccountType());
		userDTO.setAddress(user.getAddress());
		userDTO.setEmail(user.getEmail());
		userDTO.setLastName(user.getLastName());
		userDTO.setMobile(user.getMobile());
		return userDTO;

	}

	public static UserDTO convertDaoObjectToDto(User user, int userId) {
		UserDTO userDTO = new UserDTO();
		if (userId == user.getId()) {
			userDTO.setId(userId);
		}
		userDTO.setFirstName(user.getFirstName());
		userDTO.setAccountType(user.getAccountType());
		userDTO.setAddress(user.getAddress());
		userDTO.setEmail(user.getEmail());
		userDTO.setLastName(user.getLastName());
		userDTO.setMobile(user.getMobile());
		return userDTO;

	}

	/**
	 * Converts dto object to dao object
	 * 
	 * @param userdto, userId
	 * @return user object
	 */
	public static User convertDtoObjectTODao(UserDTO userdto, int userId) {
		User user = new User();
		user.setId(userId);
		user.setAccountType(userdto.getAccountType());
		user.setAddress(userdto.getAddress());
		user.setEmail(userdto.getEmail());
		user.setFirstName(userdto.getFirstName());
		user.setLastName(userdto.getLastName());
		user.setMobile(userdto.getMobile());

		return user;
	}

	/**
	 * Converts dto object to dao object
	 * 
	 * @param userdto
	 * @return user object
	 */
	public static User convertDtoObjectTODao(UserDTO userdto) {
		User user = new User();
//		user.setUserId(userdto.getid());
		user.setFirstName(userdto.getFirstName());
		user.setLastName(userdto.getLastName());
		user.setAddress(userdto.getAddress());
		user.setMobile(userdto.getMobile());
		user.setEmail(userdto.getEmail());
		user.setAccountType(userdto.getAccountType());

		return user;
	}

}