package com.pnc.user;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.pnc.user.model.entity.User;
import com.pnc.user.repository.UserRepository;

@SpringBootApplication
public class UserApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserApplication.class, args);
	}
	
    @Bean
    CommandLineRunner initDatabase(UserRepository repository) {
        return args -> {
        	User user = new User();
        	user.setAccountType("SAVING");
        	user.setAddress("Warangal");
        	user.setEmail("mymail@gmail.com");
        	user.setFirstName("Shravan");
        	user.setLastName("Rocks");
        	user.setMobile("1111111111");
        	
        	User user2 = new User();
        	user2.setAccountType("CHECKING");
        	user2.setAddress("Hyderabad");
        	user2.setEmail("shravan@gmail.com");
        	user2.setFirstName("Shravan2");
        	user2.setLastName("Rocks2");
        	user2.setMobile("2222222222");
        	
           	User user3 = new User();
        	user3.setAccountType("LOAN");
        	user3.setAddress("US");
        	user3.setEmail("us@gmail.com");
        	user3.setFirstName("Shravan3");
        	user3.setLastName("Rocks3");
        	user3.setMobile("3333333333");
        	
        	 repository.save(user);
        	 repository.save(user2);
        	 repository.save(user3);
        	 
            //repository.save(new User(1,"Shravan","Rocks","SAVING","9552702158","mymail@gmail.com","Warangal"));
        };
    }
}
