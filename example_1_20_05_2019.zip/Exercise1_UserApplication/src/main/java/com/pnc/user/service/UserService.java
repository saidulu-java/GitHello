package com.pnc.user.service;


import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.pnc.user.model.dto.UserDTO;
import com.pnc.user.model.entity.User;

/**
 * 
 * @author Shravan
 *
 */
public interface UserService {

	/**
	 * Deletes given user
	 * @param userId
	 */
	public Integer deleteUser(int userId);

	/**
	 * Updates given user
	 * @param user
	 * @return 
	 */

	public User updateUserDetails(UserDTO user, int userId);


	/**
	 * Find user given by userId
	 * @param userId
	 * @return user activeStatus
	 */
	public UserDTO findUserById(int userId);

	/**
	 * Returns list of users
	 * @return list of userDto objects
	 */
	List<User> getUsers(); 

	/**
	 * 
	 * @param user
	 * @return 
	 */

	public UserDTO saveUser(UserDTO dto);


}
