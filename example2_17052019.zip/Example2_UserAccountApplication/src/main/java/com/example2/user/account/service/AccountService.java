package com.example2.user.account.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example2.user.account.model.dto.AccountDTO;
import com.example2.user.account.model.entity.Account;

/**
 * 
 * @author Shravan
 *
 */

public interface AccountService {

	/**
	 * Find user given by userId
	 * 
	 * @param userId
	 * @return user activeStatus
	 */
	public Account findAccountById(int userId);

	/**
	 * Returns list of users
	 * 
	 * @return list of userDto objects
	 */
	List<Account> getAccount();

	/**
	 * 
	 * @param user
	 * @return
	 */

	public Account saveAccount(AccountDTO dto);


}
