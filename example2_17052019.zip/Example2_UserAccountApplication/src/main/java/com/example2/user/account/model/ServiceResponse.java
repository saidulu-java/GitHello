package com.example2.user.account.model;

import java.util.List;

/**
 * @author Shravan
 *
 */
public class ServiceResponse<T> {

	private String status;
	private T body;
	private List<ErrorResponse> errors;

	public Object getBody() {
		return body;
	}


	public String getStatus() {
		return status;
	}


	public void setBody(T body) {
		this.body = body;
	}


	public void setStatus(String status) {
		this.status = status;
	}

	public List<ErrorResponse> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorResponse> errors) {
		this.errors = errors;
	}

	public ServiceResponse() {
		// TODO Auto-generated constructor stub
	}

}
