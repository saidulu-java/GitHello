package com.example2.user.account.controller;

import java.util.List;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.example2.user.account.model.ServiceResponse;
import com.example2.user.account.model.dto.AccountDTO;
import com.example2.user.account.model.dto.UserDTO;
import com.example2.user.account.model.entity.Account;
import com.example2.user.account.service.AccountService;
import com.example2.user.account.utils.Constants;

/**
 * @author Shravan
 *
 */
@RestController
@RequestMapping()
public class AccountController {
	ServiceResponse<Object> response = new ServiceResponse<Object>();

	@Autowired
	AccountService accountService;
	
	@Value("${serviceURL}")
	String serviceURL;

	@Autowired
	RestTemplate restTemplate;

	/**
	 * POST /create --> Create a new Account and save it in the database.
	 * 
	 * @param dto
	 * @Parm custid or userid
	 * @return
	 */
	@PostMapping("/accounts/{id}")
	public ResponseEntity<ServiceResponse> createAccount(@Valid @RequestBody AccountDTO dto,
			@PathVariable Integer id) {
		

		
//        String theUrl = "http://localhost:8282/" + userId;
//        ResponseEntity<UserDTO> result = restTemplate.exchange(theUrl, HttpMethod.POST, null, UserDTO.class );
//        UserDTO user = result.getBody();

		
        ResponseEntity<UserDTO> result = restTemplate.exchange("http://localhost:8282/" + id, HttpMethod.GET, null, UserDTO.class);
        UserDTO user =result.getBody();
        System.out.println("USER ID FROM GetForObject : "+user.getId());
		dto.setId(user.getId());

		
		
		Account newAcct = accountService.saveAccount(dto);
		response.setStatus(Constants.SUCCESS);
		response.setBody(newAcct);
		return new ResponseEntity<ServiceResponse>(response, HttpStatus.CREATED);
	}

	/**
	 * @return
	 */
	@GetMapping("/getAllAccounts")
	public ResponseEntity<ServiceResponse> getAllAccounts() {

		List<Account> use = accountService.getAccount();
		if (use.size() != 0) {
			response.setStatus(Constants.SUCCESS);
			response.setBody(use);
			return new ResponseEntity<ServiceResponse>(response, HttpStatus.OK);
		} else {
			response.setStatus(Constants.ERROR);
			response.setBody(Constants.USER_NOT_EXISTS);
			return new ResponseEntity<ServiceResponse>(response, HttpStatus.NOT_FOUND);
		}
	}


}
