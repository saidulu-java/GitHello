package com.pnc.user.model;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;


@MappedSuperclass
public abstract class AbstractDomainModel<I extends Serializable> implements Serializable{


	private static final long serialVersionUID = -8317428753160593104L;
	
	@Column(name="OPENINGDATE")
	private LocalDate openingDate;

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

}
