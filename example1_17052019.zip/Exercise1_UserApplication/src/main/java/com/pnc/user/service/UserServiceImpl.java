package com.pnc.user.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pnc.user.exception.ResourceNotFoundException;
import com.pnc.user.model.dto.UserDTO;
import com.pnc.user.model.entity.User;
import com.pnc.user.repository.UserRepository;
import com.pnc.user.util.UserServiceUtil;

/**
 * @author Shravan
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	private static Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	/* (non-Javadoc)
	 * @see com.pnc.user.service.UserService#getUsers()
	 */
	@Override
	public List<User> getUsers() {
		logger.info("UserServiceImpl :: getUsers :: Get list of users");

		List<User> users = (List<User>) userRepository.findAll();
		return users;

	}

	/* (non-Javadoc)
	 * @see com.pnc.user.service.UserService#updateUserDetails(com.pnc.user.model.UserDTO, int)
	 */
	public User updateUserDetails(UserDTO newUser, int userId) {
		logger.info("UserServiceImpl :: updateUserDetails :: Updating user detail");

		return userRepository.findById(userId).map(user -> {
			user.setFirstName(newUser.getFirstName());
			user.setLastName(newUser.getLastName());
			user.setAddress(newUser.getAddress());
			user.setMobile(newUser.getMobile());
			user.setEmail(newUser.getEmail());
			user.setAccountType(newUser.getAccountType());
			return userRepository.save(user);
		}).orElseThrow(() -> new ResourceNotFoundException("User [Id=" + userId + "] can't be found"));

	}

	/* (non-Javadoc)
	 * @see com.pnc.user.service.UserService#deleteUser(int)
	 */
	@Override
	public Integer deleteUser(int userId) {
		logger.info("UserServiceImpl :: deleteUser :: Deleteing user");
		userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User [Id="+userId+"] can't be found"));
		userRepository.deleteById(userId);
		return userId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.pnc.user.service.UserService#findUserById(int)
	 */
	@Override
	public UserDTO findUserById(int userId) {
		logger.info("UserServiceImpl :: findUserById :: Finding user by userId");
		User user = userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User [Id=" + userId + "] can't be found"));
		return UserServiceUtil.convertDaoObjectToDto(user);

	}

	/* (non-Javadoc)
	 * @see com.pnc.user.service.UserService#saveUser(com.pnc.user.model.UserDTO)
	 */
	public UserDTO saveUser(UserDTO userDto) {
		logger.info("UserServiceImpl :: CreateUser :");
		User user = UserServiceUtil.convertDtoObjectTODao(userDto);
		user =  userRepository.save(user);
		userDto = UserServiceUtil.convertDaoObjectToDto(user);
		return userDto;
	}

}
