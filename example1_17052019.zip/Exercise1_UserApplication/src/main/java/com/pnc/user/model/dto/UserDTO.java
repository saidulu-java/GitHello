package com.pnc.user.model.dto;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.pnc.user.model.AbstractDomainModel;

public class UserDTO extends AbstractDomainModel<Integer> implements Serializable {

	/**
	 * Shravan
	 */
	private static final long serialVersionUID = 1L;

//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	@NotNull(message = "Please enter id")
	private Integer id;
	
	@NotNull
    @Size(max = 20, min = 5, message = "First name is mandatory with charactrs between {min = 3, max = 20}")
	private String firstName;
	
    @Size(max = 20, min = 5, message = "Last Name name is mandatory with charactrs between {min = 3, max = 20}")
	private String lastName;
	
	@NotEmpty(message = "Please enter correct address")
	private String address;
	
    @Size(max = 10, min = 10, message = "Please enter valid 10 digit phone number")
	@NotEmpty
	private String mobile;

	@NotEmpty(message = "Please enter valid Email ID")
	private String email;
	
	@NotEmpty(message = "Please provide account type")
	private String accountType;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
